package tests;

import actions.MainPageActions;
import org.testng.annotations.Test;
import pages.LoginPage;

public class CommonTest extends Base{

    @Test
    public void testData (){
        MainPageActions mainPageActions = new MainPageActions(driver);
        mainPageActions.fillAccessCode();
    }
}
