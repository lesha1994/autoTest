package pages;

import org.openqa.selenium.By;

public class LoginPage    {

    private final By AccessCode = By.xpath("//input[@id='companyId']");

    public By fieldForAccessCode(){
       return AccessCode;
    }


}
