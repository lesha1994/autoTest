package pages;

import org.openqa.selenium.WebDriver;

import static tests.Base.getDriver;

public  class BasePage {
    WebDriver driver ;
    public BasePage(WebDriver driver) {
        this.driver = getDriver();

    }



}
