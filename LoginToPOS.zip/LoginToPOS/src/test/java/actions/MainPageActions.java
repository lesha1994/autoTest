package actions;

import org.openqa.selenium.WebDriver;
import pages.BasePage;
import pages.LoginPage;

public class MainPageActions extends BasePage {

    LoginPage loginPage = new LoginPage();

    public MainPageActions(WebDriver driver) {
        super(driver);
    }

    public void fillAccessCode(){
        loginPage.fieldForAccessCode();
    }
}
